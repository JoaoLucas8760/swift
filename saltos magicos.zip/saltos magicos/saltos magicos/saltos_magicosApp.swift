//
//  saltos_magicosApp.swift
//  saltos magicos
//
//  Created by user241276 on 6/8/23.
//

import SwiftUI

@main
struct saltos_magicosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
